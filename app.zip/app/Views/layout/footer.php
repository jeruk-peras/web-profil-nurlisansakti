 <footer class="footer-bg footer-p">
     <div class="copyright-wrap">
         <div class="container">
             <div class="row align-items-center">
                 <div class="col-lg-4">

                     <img src="/img/logo/f_logo.png" alt="img">
                 </div>
                 <div class="col-lg-4">
                     <div class="copy-text text-center align-middle">
                         Copyright &copy; NUR LISAN SAKTI 2025.
                     </div>
                 </div>

                 <div class="col-lg-4 text-right text-xl-right">
                     <div class="footer-social mt-10">
                         <a href="<?= getKontak('instagram'); ?>"><i class="fab fa-instagram"></i></a>
                         <a href="<?= getKontak('facebook'); ?>"><i class="fab fa-facebook-f"></i></a>
                         <a href="<?= getKontak('youtube'); ?>"><i class="fab fa-youtube"></i></a>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </footer>