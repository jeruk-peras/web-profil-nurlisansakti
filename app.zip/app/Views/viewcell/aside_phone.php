<div class="service-detail-contact wow fadeup-animation animated" data-wow-delay="1.1s" style="visibility: visible; animation-delay: 1.1s;">
    <h3 class="h3-title">Jika anda butuh bantuan silahkan hubungi kami!</h3>
    <a href="https://wa.me/<?= getKontak('whatsapp'); ?>" title="Call now"><?= getKontak('whatsapp'); ?></a>
</div>