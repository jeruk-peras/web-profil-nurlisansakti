<section id="custom_html-5" class="widget_text widget widget_custom_html">
    <h2 class="widget-title">Ikuti Kami di</h2>
    <div class="textwidget custom-html-widget">
        <div class="widget-social">
            <a href="<?= getKontak('instagram'); ?>"><i class="fab fa-instagram"></i></a>
            <a href="<?= getKontak('facebook'); ?>"><i class="fab fa-facebook-f"></i></a>
            <a href="<?= getKontak('youtube'); ?>"><i class="fab fa-youtube"></i></a>
        </div>
    </div>
</section>