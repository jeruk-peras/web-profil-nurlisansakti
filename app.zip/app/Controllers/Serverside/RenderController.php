<?php

namespace App\Controllers\Serverside;

use App\Controllers\BaseController;
use App\Libraries\ResponseJSONCollection;
use App\Models\MenuModel;
use CodeIgniter\HTTP\ResponseInterface;

class RenderController extends BaseController
{

    // data url
    public function menu(int $id = 0)
    {
        try {
            $model = new MenuModel();

            $data = [
                'menu' => $model->when($id !== 0, function ($query) use ($id) {
                    $query->where('level', 2);
                    $query->where('parent_id', $id);
                })->when($id == 0, function ($query) {
                    $query->where('level', 1);
                })->orderBy('order', 'ASC')->findAll(),
            ];

            $html = view('admin/pages/menu/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }

    public function slider()
    {
        try {
            $data = [
                'slider' => $this->db->table('slider')->get()->getResultArray()
            ];

            $html = view('admin/pages/slider/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }

    public function service()
    {
        try {
            $data = [
                'service' => $this->db->table('service')->get()->getResultArray()
            ];

            $html = view('admin/pages/service/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }

    public function bisnis_produk()
    {
        try {
            $data = [
                'bisnis_produk' => $this->db->table('bisnis_produk')->get()->getResultArray()
            ];

            $html = view('admin/pages/bisnis_produk/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }

    public function faq()
    {
        try {
            $data = [
                'faq' => $this->db->table('faq')->get()->getResultArray()
            ];

            $html = view('admin/pages/faq/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }

    public function partner()
    {
        try {
            $data = [
                'partner' => $this->db->table('partner')->get()->getResultArray()
            ];

            $html = view('admin/pages/partner/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }

    public function kategori()
    {
        try {
            $data = [
                'kategori' => $this->db->table('kategori')->get()->getResultArray()
            ];


            $html = view('admin/pages/galeri/kategori/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }

    public function foto()
    {
        try {
            $data = [
                'galeri' => $this->db->table('galeri')
                ->select('galeri.*, kategori.kategori')
                ->join('kategori', 'kategori.id = galeri.kategori_id')->get()->getResultArray()
            ];

            $html = view('admin/pages/galeri/foto/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }
    
    public function artikel()
    {
        try {
            $data = [
                'artikel' => $this->db->table('artikel')->orderBy('created_at', 'DESC')->get()->getResultArray()
            ];

            $html = view('admin/pages/artikel/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }

    public function halaman()
    {
        try {
            $data = [
                'halaman' => $this->db->table('halaman')->orderBy('created_at', 'DESC')->get()->getResultArray()
            ];

            $html = view('admin/pages/halaman/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }

    public function karir()
    {
        try {
            $data = [
                'karir' => $this->db->table('karir')->orderBy('created_at', 'DESC')->get()->getResultArray()
            ];

            $html = view('admin/pages/karir/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }

    public function user()
    {
        try {
            $data = [
                'user' => $this->db->table('user')->orderBy('created_at', 'DESC')->get()->getResultArray()
            ];

            $html = view('admin/pages/user/side-data', $data);

            return ResponseJSONCollection::success($html, 'Success load Data', ResponseInterface::HTTP_OK);
        } catch (\Throwable $th) {
            return ResponseJSONCollection::success($th->getMessage(), 'Terjadi Kesalahan', ResponseInterface::HTTP_BAD_GATEWAY);
        }
    }
}
